# MIMOS Academy PMS V2 — Production Deployment SOP

## 0. What this deployment uses

- Frontend: React + Vite
- Backend: PocketBase
- Database: PocketBase data store
- Source control: GitHub Private Repository
- Frontend hosting: Vercel
- Backend hosting: Hostinger VPS
- Reverse proxy + HTTPS: NGINX + Certbot
- Supabase: NOT USED in this V2 release

Recommended domains:
- Frontend: `pms.mimos-academy.com`
- API/backend: `api-pms.mimos-academy.com`

Do not deploy the V2 frontend as a normal Hostinger PHP site. V2 is a React application and the PocketBase server must remain running on the VPS.

---

## 1. Before touching V1 — BACKUP FIRST

### 1.1 Do not delete or overwrite V1

Keep the current V1 site and MySQL database running until V2 has passed UAT.

The safe sequence is:

V1 backup → V2 deployment → V1 data migration → UAT → go-live → only then retire V1.

### 1.2 Back up V1 MySQL

In Hostinger:
1. Open the V1 website's database in phpMyAdmin.
2. Select the MIMOS Academy V1 database.
3. Click **Export**.
4. Choose **Quick**.
5. Format: **SQL**.
6. Download the `.sql` file.
7. Keep at least two copies.

Also download the complete V1 website files as a ZIP.

### 1.3 Verify the backup

Do not assume the backup works. Open the SQL file and confirm it contains:
- `users`
- `programs`
- `funnel`
- `upload_logs`

---

## 2. Create the GitHub repository

1. Create a new **Private** GitHub repository.
2. Recommended name: `mimos-academy-pms-v2`.
3. Do not make it public.
4. Upload the contents of the V2 source ZIP.
5. Do not upload:
   - `apps/pocketbase/pb_data/`
   - `.env`
   - production passwords
   - VPS credentials
   - database backups

The supplied V2 source already contains `.gitignore`.

---

## 3. Prepare the Hostinger VPS

Use a Hostinger VPS, not ordinary PHP shared hosting, for PocketBase.

Recommended starting point:
- Ubuntu 24.04 LTS
- 2 vCPU
- 4–8 GB RAM
- 50 GB+ SSD

SSH into the VPS:

```bash
ssh root@YOUR_VPS_IP
```

Run:

```bash
apt update && apt upgrade -y
apt install -y git nginx unzip curl certbot python3-certbot-nginx
```

Create the application directory:

```bash
mkdir -p /var/www/mimos-pms
mkdir -p /etc/mimos-pms
chmod 750 /etc/mimos-pms
```

---

## 4. Clone V2 from GitHub

```bash
cd /var/www/mimos-pms
git clone https://github.com/YOUR_ACCOUNT/mimos-academy-pms-v2.git .
```

Confirm:

```bash
ls
```

You should see:

- `apps`
- `tools`
- `package.json`
- `.gitignore`

Then:

```bash
chmod +x apps/pocketbase/pocketbase
```

---

## 5. Configure PocketBase secrets

Create:

```bash
nano /etc/mimos-pms/pocketbase.env
```

Use the template in:

`templates/pocketbase.env.example`

Generate the encryption key:

```bash
openssl rand -hex 32
```

Paste the result as:

```text
PB_ENCRYPTION_KEY=YOUR_GENERATED_VALUE
```

Create strong, unique passwords for:

```text
PB_SUPERUSER_PASSWORD
PB_BOOTSTRAP_USER_PASSWORD
```

Do not reuse your V1 password.

Example structure:

```text
PB_ENCRYPTION_KEY=...
PB_SUPERUSER_EMAIL=your-admin-email
PB_SUPERUSER_PASSWORD=...
PB_BOOTSTRAP_USER_EMAIL=your-admin-email
PB_BOOTSTRAP_USER_PASSWORD=...
PB_PUBLIC_URL=https://api-pms.mimos-academy.com
```

Secure the file:

```bash
chmod 600 /etc/mimos-pms/pocketbase.env
```

IMPORTANT:
- This file stays on the VPS.
- Never commit it to GitHub.
- Never put these values in Vercel.
- Never put the PocketBase superuser password in frontend code.

---

## 6. Configure DNS

At the DNS provider for `mimos-academy.com`:

### Backend

Create:

```text
Type: A
Name: api-pms
Value: YOUR_HOSTINGER_VPS_IP
```

### Frontend

Vercel will provide the DNS target for:

```text
pms.mimos-academy.com
```

Do not guess the Vercel target. Copy the exact DNS instruction Vercel gives you.

Wait for DNS propagation.

Test backend DNS:

```bash
ping api-pms.mimos-academy.com
```

The returned IP should be your Hostinger VPS IP.

---

## 7. Configure NGINX

Copy:

`nginx/mimos-pms-api.conf`

to:

```text
/etc/nginx/sites-available/mimos-pms-api
```

Then:

```bash
ln -s /etc/nginx/sites-available/mimos-pms-api /etc/nginx/sites-enabled/mimos-pms-api
```

Test:

```bash
nginx -t
```

Expected:

```text
syntax is ok
test is successful
```

Reload:

```bash
systemctl reload nginx
```

---

## 8. Configure PocketBase service

Copy:

`systemd/mimos-pms.service`

to:

```text
/etc/systemd/system/mimos-pms.service
```

Then:

```bash
systemctl daemon-reload
systemctl enable mimos-pms
systemctl start mimos-pms
```

Check:

```bash
systemctl status mimos-pms
```

It should show:

```text
Active: active (running)
```

---

## 9. Test PocketBase locally

On the VPS:

```bash
curl http://127.0.0.1:8090/api/health
```

Expected:

```json
{"message":"API is healthy.","code":200,"data":{}}
```

If this works, PocketBase itself is running.

---

## 10. Configure HTTPS

Run:

```bash
certbot --nginx -d api-pms.mimos-academy.com
```

Follow the prompts.

Then test:

```text
https://api-pms.mimos-academy.com/api/health
```

Expected response:

```json
{"message":"API is healthy.","code":200,"data":{}}
```

Test certificate renewal:

```bash
certbot renew --dry-run
```

---

## 11. Run V2 database migrations

The V2 release contains PocketBase migrations.

Run:

```bash
cd /var/www/mimos-pms/apps/pocketbase
source /etc/mimos-pms/pocketbase.env
./pocketbase migrate up \
  --encryptionEnv=PB_ENCRYPTION_KEY \
  --dir=./pb_data \
  --migrationsDir=./pb_migrations \
  --hooksDir=./pb_hooks
```

The migrations create:
- users
- clients
- client contacts
- opportunities
- quotations
- purchase orders
- programmes
- training delivery
- training statistics
- participants
- invoices
- payments
- action items
- documents
- audit history

They also apply the role-based backend security rules.

---

## 12. Create the initial Super Admin

The V2 migration uses:

```text
PB_BOOTSTRAP_USER_EMAIL
PB_BOOTSTRAP_USER_PASSWORD
```

to create the first application Super Admin.

After migration, verify the account by logging in through the application.

Do not use the old V1 credentials.

---

## 13. Optional: load the supplied V2 sample/business dataset

The V2 source includes a seed script:

```text
tools/seed-v2.mjs
```

This loads the business dataset supplied with the V2 design into PocketBase.

Run it only on an empty V2 database.

From the V2 project root:

```bash
cd /var/www/mimos-pms

PB_URL=https://api-pms.mimos-academy.com \
PB_SUPERUSER_EMAIL=YOUR_SUPERUSER_EMAIL \
PB_SUPERUSER_PASSWORD='YOUR_SUPERUSER_PASSWORD' \
node tools/seed-v2.mjs
```

The script has been tested against the V2 PocketBase schema.

It loads approximately:
- 40 clients
- 38 programmes
- 97 opportunities
- 27 quotations
- 4 purchase orders
- 36 invoices
- 22 payments
- 38 training sessions
- 38 training statistics
- 50 action items
- 96 audit-history records

If your intention is to migrate the actual V1 database instead, do NOT run the V2 seed first.

---

## 14. Optional: migrate the real V1 database

Use:

```text
tools/migrate-v1-to-v2.php
```

This is intended for the V1 MySQL database currently hosted on Hostinger.

It migrates:
- V1 clients → V2 clients
- V1 programs → V2 programmes
- V1 quotation data → V2 quotations
- V1 PO data → V2 purchase orders
- V1 invoice data → V2 invoices
- V1 collection data → V2 payments
- V1 funnel → V2 opportunities

It intentionally does NOT copy V1 password hashes.

Create/reprovision staff accounts in V2 through the Super Admin interface.

Before running it:
1. Keep V1 online.
2. Make the V1 SQL backup.
3. Confirm V2 migrations are complete.
4. Confirm V2 has a Super Admin.
5. Set the V1 MySQL environment variables.
6. Set V2 PocketBase URL and Super Admin credentials.
7. Run the script.
8. Check the migrated records.
9. Do not delete V1 yet.

---

## 15. Deploy frontend to Vercel

Go to Vercel and create a new project.

1. Import the GitHub repository.
2. Select the V2 repository.
3. Set **Root Directory** to:

```text
apps/web
```

4. Framework preset: Vite.
5. Build command:

```text
npm run build
```

6. Output directory:

```text
dist
```

7. Add Environment Variable:

```text
VITE_POCKETBASE_URL
```

Value:

```text
https://api-pms.mimos-academy.com
```

Use this variable for Production, Preview and Development as appropriate.

Do not add:
- `PB_SUPERUSER_PASSWORD`
- `PB_ENCRYPTION_KEY`
- any PocketBase server credential

to Vercel.

---

## 16. Configure Vercel custom domain

Add:

```text
pms.mimos-academy.com
```

to the Vercel project.

Follow Vercel's exact DNS instruction.

Then test:

```text
https://pms.mimos-academy.com
```

---

## 17. First login test

Open:

```text
https://pms.mimos-academy.com
```

Login with the V2 Super Admin account.

Immediately verify:
- Dashboard loads
- clients load
- opportunities load
- programmes load
- quotations load
- POs load
- invoices load
- payments load
- action items load
- administration loads

If the dashboard is blank:
1. Open browser DevTools.
2. Check Network.
3. Look for requests to `api-pms.mimos-academy.com`.
4. Check whether the request is blocked by CORS, DNS or HTTPS.
5. Check PocketBase logs.

---

## 18. Role/UAT testing

Create one test account for each role:

- Super Admin
- Manager
- Finance
- Sales
- Programme PIC
- Trainer
- Viewer

### Super Admin
Must be able to:
- manage users
- see all modules
- create/update/delete permitted records

### Manager
Must be able to:
- monitor sales pipeline
- monitor programmes
- monitor finance
- manage operational records
- NOT manage users

### Sales
Must be able to:
- clients
- opportunities
- quotations
- POs
- programme visibility

### Finance
Must be able to:
- quotations
- POs
- invoices
- payments
- financial reporting

### Programme PIC
Must be able to:
- clients
- programmes
- training
- participants
- action items

### Trainer
Must be able to:
- training delivery
- participants
- training statistics
- action items

### Viewer
Must be read-only.

IMPORTANT:
Do not test only by hiding menu items. Test direct API permissions too. V2 applies role restrictions at the PocketBase backend.

---

## 19. Test the core business workflow

Create a test record:

```text
Client
  ↓
Opportunity
  ↓
Quotation
  ↓
Purchase Order
  ↓
Programme
  ↓
Training Delivery
  ↓
Invoice
  ↓
Payment
```

Then open the Programme Hub and confirm the related records appear.

---

## 20. Test programme monitoring

For an existing programme:

1. Open Programmes.
2. Open Programme Hub.
3. Click Update Status.
4. Change:
   - Status
   - Progress %
5. Save.
6. Return to Dashboard.
7. Confirm the updated status/progress is reflected.

This is the main V2 improvement over V1 for programme monitoring.

---

## 21. Test action-item monitoring

1. Open Action Items.
2. Create an action item.
3. Set owner.
4. Set due date.
5. Set priority.
6. Save.
7. Mark it Done.
8. Confirm it changes to Completed.

Action items are stored in PocketBase, not browser memory.

---

## 22. Backup strategy

Create a backup folder:

```bash
mkdir -p /var/backups/mimos-pms
```

Use:

`scripts/03-backup-pocketbase.sh`

or run:

```bash
tar -czf /var/backups/mimos-pms/pb_data_$(date +%Y%m%d_%H%M%S).tar.gz \
  -C /var/www/mimos-pms/apps/pocketbase pb_data
```

Recommended:
- Daily backup
- Keep 30 days
- Weekly copy to an external location
- Monthly archive

Do not store the only backup on the same VPS.

---

## 23. Updating V2 later

### Frontend changes

Developer/AI changes code → push to GitHub.

Vercel automatically builds and deploys.

### Backend changes

SSH to VPS:

```bash
cd /var/www/mimos-pms
git pull origin main
```

Then:

```bash
cd apps/pocketbase
source /etc/mimos-pms/pocketbase.env
./pocketbase migrate up \
  --encryptionEnv=PB_ENCRYPTION_KEY \
  --dir=./pb_data \
  --migrationsDir=./pb_migrations \
  --hooksDir=./pb_hooks
```

Restart:

```bash
systemctl restart mimos-pms
```

Check:

```bash
systemctl status mimos-pms
```

Always back up `pb_data` before a database migration.

---

## 24. What NOT to do

Do NOT:
- delete V1 before UAT
- put PocketBase admin credentials in React/Vercel
- commit `.env`
- commit `pb_data`
- expose port 8090 directly to the internet
- use the V1 default password
- make the GitHub repository public
- run the sample seed after migrating real V1 data
- change PocketBase schema manually without a migration
- bypass the backend role rules
- rely only on browser/menu permissions

---

## 25. Final production architecture

```text
                         USERS
                           |
                           v
              https://pms.mimos-academy.com
                           |
                           v
                        VERCEL
                     React + Vite
                           |
                           | HTTPS API
                           v
          https://api-pms.mimos-academy.com
                           |
                           v
                       HOSTINGER
                           |
                         NGINX
                           |
                           v
                      PocketBase
                           |
                           v
                        pb_data
                           |
                           v
                    Daily Backups
```

GitHub sits above the deployment process:

```text
GitHub
  |
  +----> Vercel --------> Frontend
  |
  +----> Hostinger VPS --> PocketBase
```

Supabase is intentionally not part of this V2 architecture because the supplied V2 application is already designed around PocketBase. Migrating to Supabase would be a separate database/backend rewrite project.
