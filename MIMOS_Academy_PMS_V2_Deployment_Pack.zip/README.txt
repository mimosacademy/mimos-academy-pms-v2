MIMOS Academy PMS V2 Deployment Pack

Read SOP_V2_DEPLOYMENT.md first.

Folders:
- nginx/       NGINX reverse proxy configuration
- systemd/     PocketBase systemd service
- scripts/     server setup, backend update and backup scripts
- templates/   server and Vercel environment variable templates

Do not put real passwords into these files.
